# Texture-Mapping-Sphere
The program uses the texture mapping technique in OpenGL.

![alt tag](http://glasnost.itcarlow.ie/~powerk/GeneralGraphicsNotes/texturemapping/texture_mapping.jpg)
